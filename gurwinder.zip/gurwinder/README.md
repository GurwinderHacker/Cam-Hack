# HACK-CAMERA
![PicsArt_22-05-29_10-48-11-232](https://user-images.githubusercontent.com/70594016/170853488-00bb3f9c-768b-4313-83ba-535683a75c82.png)


###### HACK CAMERA LIVE WITH CLOUDFLARED LINK.
***
### <p align="center">Commands to run tool in ur terminal Termux && Kali Linux
***

```bash
Note : Tool is Made of Educational Purposes only.
       Please try not to harm anyone device 
       it's For Fun Purpose Not For Revenge
       (Join Us https://bit.ly/3PV3S3r)
```
### [+] Features
 - Three Templates (More Templates Coming Soon)
 - Get IP, Location, Device type and Browser
 - Dual Tunneling (Cloudflare && ngrok)
 - Choose where to save images(custom directory) 
 - Error Diagnoser
 - Argument support for templates, tunnelers and directory
       
 ## The Tool is for :
- Kali Linux
- Termux
- MacOS
- Ubuntu
- Perrot Sec OS
- Garuda Linux     
 
 ## Language is used to Make this tool
- Bash Script
- HTML
- PHP
- JavaScript
- CSS
 
 TUTORIAL: https://youtu.be/zaBU9I_KGXk
       
## How Works ?
First of all This tool host a phishing site on attacker local network. This tool gives two port forwarding option (NGROK or CloudFlare) to take website over the internet. Now come on the main Point, attacker simply open the tool by using terminal and generate a link, when Link is generated attacker send that link to the target. If target open the link, target ip will transfer to the attacker. After Website load, the website ask for Camera access and when target give the permission the website will take cam shots one by one and send it to the Attacker
       
###### Installation
```bash
apt update && apt upgrade -y
```
```bash
apt install git -y
```
```bash
apt install php
```
```bash
apt install curl -y
```
```bash
apt install wget -y
```
```bash
git clone https://github.com/XPH4N70M/HACK-CAMERA.git
```
```bash
cd HACK-CAMERA
```
```bash
chmod +x hack_camera.sh (optional)
```
```bash
bash setup
```
```bash
bash hack_camera.sh
```
###### For Termux Additional Command 
```bash
 termux-setup-storage
 ```
 ###### Disclaimer
 This tool is developed for educational purposes. Here it demonstrates how camera phishing works. If anybody wants to gain unauthorized access to someones camera, he/she may try out this at his/her own risk. You have your own responsibilities and you are liable to any damage or violation of laws by this tool. The author is not responsible for any misuse of HACK-CAMERA!
       
##### <p align="center">```And Thanks for choosing this tool Support Us !```
